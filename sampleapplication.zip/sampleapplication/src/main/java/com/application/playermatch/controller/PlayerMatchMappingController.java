package com.application.playermatch.controller;

import javax.persistence.NoResultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.application.player.service.PlayerService;
import com.application.playermatch.response.PlayerDetailsResponseWrapper;
import com.application.playermatch.response.PlayerMatchResponseDTO;
import com.application.playermatch.response.ResponseWrapper;
import com.application.playermatch.response.Status;
import com.application.playermatch.service.PlayerMatchDetailsService;

@RestController
public class PlayerMatchMappingController {
	
	Logger logger = LoggerFactory.getLogger(PlayerMatchMappingController.class);

	
	@Autowired
	private PlayerMatchDetailsService playerMatchDetailsService;
	
	@Autowired
	private PlayerService playerService;
	
	@GetMapping("/getPlayerInfo/{playerId}")
	public ResponseWrapper getPlayerInfo(@PathVariable Integer playerId) {
		
		logger.info("PlayerId -- " + playerId);
		
		boolean isPlayerExist =	playerService.checkIfPlayerExist(playerId);
		
		logger.info("Check if player Exist -- "+isPlayerExist);
		
		if(!isPlayerExist)
			return new ResponseWrapper(new Status("No record found", 404, "Player does not exist with given id"));
		
		
		PlayerMatchResponseDTO playerInformation = playerMatchDetailsService.getPlayerAndScoreInfo(playerId);
		
		PlayerDetailsResponseWrapper playerDetailsResponseWrapper = new com.application.playermatch.response.PlayerDetailsResponseWrapper(new Status("Successfully fetched", 200, ""), playerInformation);
		logger.info("Send response if player exist exist");
		
		return playerDetailsResponseWrapper ;
		
	}

}
