package com.application.playermatch.response;

public class Status {
	
	private String message;
	private Integer code;
	private String cause;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	public Status(String message, Integer code, String cause) {
		super();
		this.message = message;
		this.code = code;
		this.cause = cause;
	}
	
	

}
