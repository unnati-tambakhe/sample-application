package com.application.playermatch.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import com.application.player.entity.PlayerDetailsResponseEntity;
import com.application.playermatch.entity.MatchDetailsResponseEntity;
import com.application.playermatch.response.MatchDetailsDTO;
import com.application.playermatch.response.PlayerMatchResponseDTO;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface PlayerDetailsResponseMapper {
	
	MatchDetailsDTO toResponseDTO(MatchDetailsResponseEntity entity);

	List<MatchDetailsDTO> toResponseDTOList(List<MatchDetailsResponseEntity> entityList);
	
	
	PlayerMatchResponseDTO toPlayerResponseDTO(PlayerDetailsResponseEntity playerEntity);

	
	
}
