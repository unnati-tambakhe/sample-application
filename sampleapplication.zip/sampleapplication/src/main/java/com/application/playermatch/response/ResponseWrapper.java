package com.application.playermatch.response;

public class ResponseWrapper {
	
	private Status status;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public ResponseWrapper(Status status) {
		super();
		this.status = status;
	}
	
	

}
