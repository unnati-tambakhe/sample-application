package com.application.playermatch.dao;

import java.util.List;

import com.application.player.entity.PlayerDetailsResponseEntity;
import com.application.playermatch.entity.MatchDetailsResponseEntity;

public interface PlayerMatchDao {
	
	
	List<MatchDetailsResponseEntity> getPlayerInfo(Integer playerId);
	
	PlayerDetailsResponseEntity getTotalScoreOfPlayer(Integer playerId);

}
