package com.application.playermatch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.player.entity.PlayerDetailsResponseEntity;
import com.application.playermatch.dao.PlayerMatchDao;
import com.application.playermatch.entity.MatchDetailsResponseEntity;
import com.application.playermatch.mapper.PlayerDetailsResponseMapper;
import com.application.playermatch.response.PlayerMatchResponseDTO;
import com.application.playermatch.service.PlayerMatchDetailsService;

@Service
public class PlayerMatchDetailsServiceImpl implements PlayerMatchDetailsService {
	
	@Autowired
	private PlayerMatchDao playerMatchDao;
	
	@Autowired
	private PlayerDetailsResponseMapper playerDetailsResponseMapper;

	@Override
	public PlayerMatchResponseDTO getPlayerAndScoreInfo(Integer playerId) {
		
		List<MatchDetailsResponseEntity> matchesPlayed = playerMatchDao.getPlayerInfo(playerId);
		PlayerDetailsResponseEntity playerInfo = playerMatchDao.getTotalScoreOfPlayer(playerId);
		
		PlayerMatchResponseDTO playerResponseDTO = playerDetailsResponseMapper.toPlayerResponseDTO(playerInfo);
		playerResponseDTO.setMatchDetails(playerDetailsResponseMapper.toResponseDTOList(matchesPlayed));
		
		
		return playerResponseDTO;
		
	}

}
