package com.application.playermatch.entity;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.application.match.entity.MatchDetails;
import com.application.player.entity.PlayerDetails;
import com.application.player.entity.PlayerDetailsResponseEntity;


@SqlResultSetMapping(name="MatchDetailsResponseMapping",
classes = {
 @ConstructorResult(targetClass = MatchDetailsResponseEntity.class,
   columns = {@ColumnResult(name="matchId"),@ColumnResult(name="seriesName"), @ColumnResult(name="location"),@ColumnResult(name="score")}
 )}
)



@SqlResultSetMapping(name="PlayerDetailsResponseMapping",
classes = {
 @ConstructorResult(targetClass = PlayerDetailsResponseEntity.class,
   columns = {@ColumnResult(name="playerId"),@ColumnResult(name="playerName"), @ColumnResult(name="cricketTeam"),@ColumnResult(name="totalScore")}
 )}
)


@Entity
@Table
public class PlayerMatchMappingDetails {
	
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="player_id")
	private PlayerDetails playerDetails;
	
	
	
	@ManyToOne
	@JoinColumn(name="match_id")
	private MatchDetails matchDetails;
	
	
	@Column
	private Integer score;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public PlayerDetails getPlayerDetails() {
		return playerDetails;
	}
	public void setPlayerDetails(PlayerDetails playerDetails) {
		this.playerDetails = playerDetails;
	}
	public MatchDetails getMatchDetails() {
		return matchDetails;
	}
	public void setMatchDetails(MatchDetails matchDetails) {
		this.matchDetails = matchDetails;
	}
	
	
	
	
	



}
