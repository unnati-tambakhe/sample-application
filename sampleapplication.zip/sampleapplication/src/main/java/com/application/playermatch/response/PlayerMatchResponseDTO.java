package com.application.playermatch.response;

import java.util.List;

public class PlayerMatchResponseDTO {

	
	private Integer playerId;
	private String playerName;
	private String cricketTeam;
	private Object totalScore;
	private List<MatchDetailsDTO> matchDetails;
	
	
	
	public Object getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(Object totalScore) {
		this.totalScore = totalScore;
	}
	public List<MatchDetailsDTO> getMatchDetails() {
		return matchDetails;
	}
	public void setMatchDetails(List<MatchDetailsDTO> matchDetails) {
		this.matchDetails = matchDetails;
	}
	public Integer getPlayerId() {
		return playerId;
	}
	public void setPlayerId(Integer playerId) {
		this.playerId = playerId;
	}
	
	public String getCricketTeam() {
		return cricketTeam;
	}
	public void setCricketTeam(String cricketTeam) {
		this.cricketTeam = cricketTeam;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	
	
	
}
