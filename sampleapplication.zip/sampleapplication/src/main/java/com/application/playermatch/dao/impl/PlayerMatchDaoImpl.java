package com.application.playermatch.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.application.player.entity.PlayerDetailsResponseEntity;
import com.application.playermatch.dao.PlayerMatchDao;
import com.application.playermatch.entity.MatchDetailsResponseEntity;

@Component
public class PlayerMatchDaoImpl implements PlayerMatchDao {
	
	
	@PersistenceContext
    private EntityManager entityManager;

	@Override
	public List<MatchDetailsResponseEntity> getPlayerInfo(Integer playerId) {
		
		String queryString = "SELECT m.match_id AS matchId,m.series_name AS seriesName,m.location AS location,pm.score AS score from player_match_mapping_details pm,match_details m WHERE player_id = :playerId AND m.match_id=pm.match_id";
		
		Query query = entityManager.createNativeQuery(queryString,"MatchDetailsResponseMapping");
		query.setParameter("playerId", playerId);
		
		List<MatchDetailsResponseEntity> resultList =  query.getResultList();
		return resultList;
	}

	@Override
	public PlayerDetailsResponseEntity getTotalScoreOfPlayer(Integer playerId) {
		
		String queryString = "SELECT pd.player_id AS playerId,pd.player_name AS playerName,pd.cricket_team AS cricketTeam,SUM(score) AS totalScore from player_details pd,player_match_mapping_details pm where pm.player_id = :playerId AND pd.player_id = pm.player_id";
		
		Query query = entityManager.createNativeQuery(queryString,"PlayerDetailsResponseMapping");
		query.setParameter("playerId", playerId);
		
		PlayerDetailsResponseEntity playerDetails =  (PlayerDetailsResponseEntity) query.getSingleResult();
		return playerDetails;
	}

}
