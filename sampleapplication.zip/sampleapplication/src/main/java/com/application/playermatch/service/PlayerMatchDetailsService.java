package com.application.playermatch.service;

import com.application.playermatch.response.PlayerMatchResponseDTO;

public interface PlayerMatchDetailsService {
	
	PlayerMatchResponseDTO getPlayerAndScoreInfo(Integer playerId);

}
