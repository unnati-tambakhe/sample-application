package com.application.playermatch.response;

public class PlayerDetailsResponseWrapper extends ResponseWrapper {
	
	private PlayerMatchResponseDTO playerInformation;
	
	

	public PlayerMatchResponseDTO getPlayerInformation() {
		return playerInformation;
	}



	public void setPlayerInformation(PlayerMatchResponseDTO playerInformation) {
		this.playerInformation = playerInformation;
	}



	public PlayerDetailsResponseWrapper(Status status) {
		super(status);
	}



	public PlayerDetailsResponseWrapper(Status status, PlayerMatchResponseDTO playerInformation) {
		super(status);
		this.playerInformation = playerInformation;
	}

	
	
}
