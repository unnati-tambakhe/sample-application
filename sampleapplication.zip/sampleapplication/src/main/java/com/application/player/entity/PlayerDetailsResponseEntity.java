package com.application.player.entity;

public class PlayerDetailsResponseEntity {

	
	private Integer playerId;
	private String playerName;
	private String cricketTeam;
	private Object totalScore;
	
	
	
	public Object getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(Object totalScore) {
		this.totalScore = totalScore;
	}
	public Integer getPlayerId() {
		return playerId;
	}
	public void setPlayerId(Integer playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getCricketTeam() {
		return cricketTeam;
	}
	public void setCricketTeam(String cricketTeam) {
		this.cricketTeam = cricketTeam;
	}
	
	
	public PlayerDetailsResponseEntity(Integer playerId, String playerName, String cricketTeam,Object totalScore) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.cricketTeam = cricketTeam;
		this.totalScore = totalScore;
	}
	
	
}
