package com.application.player.dao.impl;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.application.player.dao.PlayerDao;
import com.application.player.entity.PlayerDetails;

@Component
public class PlayerDetailsDaoImpl implements PlayerDao {

	@PersistenceContext
    private EntityManager entityManager;

	@Override
	public PlayerDetails findPlayerById(Integer id) {
		
		
		String queryString = "SELECT * from player_details where player_id =:playerId";
		
		Query query = entityManager.createNativeQuery(queryString,PlayerDetails.class);
		query.setParameter("playerId", id);
		
		PlayerDetails result =  (PlayerDetails) query.getSingleResult();
		return result;
	}

}
