package com.application.player.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.application.match.entity.MatchDetails;

@Entity
@Table
public class PlayerDetails {
	
	
	@Id
	@Column(name="player_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(name="player_name")
	private String name;
	
	@Column(name="cricket_team")
	private String cricketTeam;
	
	
//	@OneToMany(mappedBy="player")	
//	private Set<MatchDetails> matches;
//	
	
	
	
	
	
//	public Set<MatchDetails> getMatches() {
//		return matches;
//	}
//	public void setMatches(Set<MatchDetails> matches) {
//		this.matches = matches;
//	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCricketTeam() {
		return cricketTeam;
	}
	public void setCricketTeam(String cricketTeam) {
		this.cricketTeam = cricketTeam;
	}
	
	
	
	

}


