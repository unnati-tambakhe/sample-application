package com.application.player.dao;

import javax.persistence.NoResultException;

import org.springframework.data.repository.CrudRepository;

import com.application.player.entity.PlayerDetails;

public interface PlayerDao {
	
	PlayerDetails findPlayerById(Integer id);

}
