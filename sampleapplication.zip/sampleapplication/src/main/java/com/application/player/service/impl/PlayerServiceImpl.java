package com.application.player.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.player.dao.PlayerDao;
import com.application.player.entity.PlayerDetails;
import com.application.player.service.PlayerService;

@Service
public class PlayerServiceImpl implements PlayerService {
	
	@Autowired
	private PlayerDao playerDao;

	@Override
	public boolean checkIfPlayerExist(Integer playerId) {
		
		try {
			PlayerDetails player = playerDao.findPlayerById(playerId);
			if(player != null) {
				System.out.println("player exist");
				return true;

			}
			
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
