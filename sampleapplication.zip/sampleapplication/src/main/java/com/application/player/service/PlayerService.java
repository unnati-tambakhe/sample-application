package com.application.player.service;

public interface PlayerService {
	
	boolean checkIfPlayerExist(Integer playerId);

}
