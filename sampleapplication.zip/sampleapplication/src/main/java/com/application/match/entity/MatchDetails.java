package com.application.match.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.application.player.entity.PlayerDetails;

@Entity
@Table
public class MatchDetails {
	
	
	@Id
	@Column(name="match_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(name="series_name")
	private String seriesName;
	@Column
	private String location;
	
	
//	@ManyToOne
//	private PlayerDetails player;
//	
//	
//	
//	
//	
//	
//	public PlayerDetails getPlayer() {
//		return player;
//	}
//	public void setPlayer(PlayerDetails player) {
//		this.player = player;
//	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSeriesName() {
		return seriesName;
	}
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
	

}


