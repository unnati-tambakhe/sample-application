insert into player_details(player_id, player_name,cricket_team) values (1, 'Brett Lee','Australia');
insert into player_details(player_id, player_name,cricket_team) values (2, 'Virat Kohli','India');
insert into player_details(player_id, player_name,cricket_team) values (3, 'M S Dhoni','Australia');
insert into player_details(player_id, player_name,cricket_team) values (4, 'Kumar Sangakara','Sri Lanka');



insert into match_details(match_id, series_name,location) values (1, 'Asia Cup','Mumbai Stadium');
insert into match_details(match_id, series_name,location) values (2, 'World Cup','Kolkata');
insert into match_details(match_id, series_name,location) values (3, 'Ranji Trophy','Pune');
insert into match_details(match_id, series_name,location) values (4, 'IPL','Mumbai Stadium');

insert into player_match_mapping_details(id,player_id,match_id, score) values (1, 1,1,33);
insert into player_match_mapping_details(id,player_id,match_id, score) values (2, 1,3,102);
insert into player_match_mapping_details(id,player_id,match_id, score) values (3, 2,1,78);
insert into player_match_mapping_details(id,player_id,match_id, score) values (4, 2,2,55);
insert into player_match_mapping_details(id,player_id,match_id, score) values (5, 3,1,65);
