
create table player_details(
    player_id int not null primary key,
    player_name varchar(100) not null,
    cricket_team varchar(100) not null
);


