ALTER TABLE player_match_mapping_details
   ADD CONSTRAINT FK_Match_Id FOREIGN KEY (match_id)
      REFERENCES match_details (match_id)
      ON DELETE CASCADE
      ON UPDATE CASCADE
;
