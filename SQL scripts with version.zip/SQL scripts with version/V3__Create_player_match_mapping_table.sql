create table player_match_mapping_details(
    id int not null primary key,
    player_id int not null,
    match_id int not null,
    score int
);

