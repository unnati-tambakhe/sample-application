ALTER TABLE player_match_mapping_details
   ADD CONSTRAINT FK_Player_Id FOREIGN KEY (player_id)
      REFERENCES player_details (player_id)
      ON DELETE CASCADE
      ON UPDATE CASCADE
;
