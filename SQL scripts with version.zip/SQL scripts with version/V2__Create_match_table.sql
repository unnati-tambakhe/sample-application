create table match_details(
    match_id int not null primary key,
    series_name varchar(100) not null,
    location varchar(100) not null
);

